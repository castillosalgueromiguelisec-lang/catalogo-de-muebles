// Catálogo: para agregar un producto basta con sumar un objeto a este array.
const PRODUCTOS = [
  { id: 1, nombre: "Silla de oficina ergonómica", categoria: "sillas", precio: 200, imagen: "img/pr1.png", descripcion: "Respaldo lumbar y altura regulable." },
  { id: 2, nombre: "Silla ejecutiva", categoria: "sillas", precio: 200, imagen: "img/pr2.png", descripcion: "Tapizado premium con base cromada." },
  { id: 3, nombre: "Sillón relax individual", categoria: "sillones", precio: 200, imagen: "img/pr3.png", descripcion: "Asiento profundo para leer o descansar." },
  { id: 4, nombre: "Sillón puff individual", categoria: "sillones", precio: 150, imagen: "img/pr4.png", descripcion: "Compacto, suave y fácil de mover." },
  { id: 5, nombre: "Sillón reclinable", categoria: "sillones", precio: 125, descuento: 15, imagen: "img/1.png", descripcion: "Reclinación manual en tres posiciones." },
  { id: 6, nombre: "Silla Marely", categoria: "sillas", precio: 175, imagen: "img/2.png", descripcion: "Diseño liviano para comedor o escritorio." },
  { id: 7, nombre: "Sillón tapizado", categoria: "sillones", precio: 160, descuento: 15, imagen: "img/3.png", descripcion: "Tela resistente y espuma de alta densidad." },
  { id: 8, nombre: "Sillón reclinable ejecutivo", categoria: "sillones", precio: 350, imagen: "img/4.png", descripcion: "Cuero sintético con reposapiés integrado." },
  { id: 9, nombre: "Silla ejecutiva giratoria", categoria: "sillas", precio: 50, descuento: 15, imagen: "img/5.png", descripcion: "Giro de 360° con ruedas silenciosas." },
  { id: 10, nombre: "Silla de escritorio ergonómica", categoria: "sillas", precio: 70, imagen: "img/6.png", descripcion: "Malla transpirable para jornadas largas." }
];

const NOTICIAS = [
  { id: 1, titulo: "Cómo elegir una silla ergonómica", imagen: "img/b1.jpg", resumen: "Cuatro puntos a revisar antes de comprar tu silla de oficina.",
    texto: ["Pasamos más de ocho horas al día sentados, así que la silla importa más que el escritorio.", "Revisa que el respaldo siga la curva lumbar, que la altura permita apoyar los pies en el piso y que los apoyabrazos queden a la altura del codo.", "Si puedes, prueba la silla unos minutos: la comodidad real se nota rápido."] },
  { id: 2, titulo: "Cuidado y limpieza de sillones tapizados", imagen: "img/b2.jpg", resumen: "Consejos simples para que tu sillón dure muchos años.",
    texto: ["Aspira el sillón una vez por semana para retirar polvo y migas.", "Ante una mancha, seca con un paño sin frotar y usa agua con jabón neutro.", "Evita la exposición directa al sol para que la tela no pierda color."] },
  { id: 3, titulo: "Tendencias 2026 para tu sala", imagen: "img/b3.jpg", resumen: "Tonos tierra, formas curvas y piezas que combinan comodidad y estilo.",
    texto: ["Los sillones de formas redondeadas ganan espacio en las salas modernas.", "Los tonos tierra y los neutros cálidos combinan con casi cualquier ambiente.", "Una pieza protagonista, como un sillón de color, alcanza para renovar el espacio."] }
];
