const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const precioFinal = p => p.descuento ? p.precio * (1 - p.descuento / 100) : p.precio;
const money = n => "$" + (Math.round(n * 100) / 100).toString();

/* ---------- Layout compartido (encabezado, carrito y pie) ---------- */
function montarLayout() {
  const pag = location.pathname.split("/").pop() || "index.html";
  const link = (href, txt) => `<li><a href="${href}"${pag === href ? ' aria-current="page"' : ""}>${txt}</a></li>`;
  $("#encabezado").innerHTML = `
    <div class="menu container">
      <a href="index.html" class="logo" aria-label="Miguel, ir al inicio">
        <svg viewBox="0 0 32 32" width="30" height="30" aria-hidden="true"><path d="M9 3h14a2 2 0 0 1 2 2v12H7V5a2 2 0 0 1 2-2zm-4 15h22v4H5zm3 5h3v6H8zm13 0h3v6h-3z" fill="currentColor"/></svg>
        <span>Miguel</span></a>
      <input type="checkbox" id="menu" aria-label="Abrir menú">
      <label for="menu"><img src="img/menu.png" class="menu-icono" alt="Menú"></label>
      <nav class="navbar"><ul>
        ${link("index.html", "Inicio")}${link("index.html#servicios", "Servicios")}
        ${link("productos.html", "Productos")}${link("index.html#contacto", "Contacto")}
      </ul></nav>
      <button class="btn-carrito" id="abrir-carrito" aria-label="Abrir carrito">
        <img src="img/car.svg" alt=""><span id="cuenta-carrito">0</span></button>
    </div>`;
  $("#pie").innerHTML = `
    <div class="link"><h3>Miguel</h3><p>Sillas y sillones con garantía.<br>La Paz, Bolivia</p></div>
    <div class="link"><h3>Tienda</h3><ul>
      <li><a href="productos.html">Todo el catálogo</a></li>
      <li><a href="productos.html?cat=sillas">Sillas</a></li>
      <li><a href="productos.html?cat=sillones">Sillones</a></li>
      <li><a href="productos.html?filtro=ofertas">Promociones</a></li></ul></div>
    <div class="link"><h3>Ayuda</h3><ul>
      <li><a href="index.html#servicios">Servicios</a></li>
      <li><a href="index.html#noticias">Noticias</a></li>
      <li><a href="index.html#contacto">Contacto</a></li>
      <li><a href="#inicio">Volver arriba</a></li></ul></div>`;
  document.body.insertAdjacentHTML("beforeend", `
    <div class="velo" id="velo"></div>
    <aside class="drawer" id="drawer" aria-label="Carrito de compras" aria-hidden="true">
      <div class="drawer-top"><h2>Tu carrito</h2><button id="cerrar-carrito" class="cerrar" aria-label="Cerrar carrito">×</button></div>
      <div id="items" class="items"></div>
      <div class="drawer-pie">
        <p class="total">Total <strong id="total">$0</strong></p>
        <button class="btn-1 lleno" id="finalizar">Finalizar compra</button>
        <button class="btn-link" id="vaciar">Vaciar carrito</button>
      </div></aside>
    <dialog id="dlg"><h2 id="dlg-t"></h2><p id="dlg-p"></p><button class="btn-1 lleno" id="dlg-ok">Entendido</button></dialog>
    <div class="toast" id="toast" role="status"></div>`);
  $("#menu").addEventListener("change", () => {});
  $$(".navbar a").forEach(a => a.addEventListener("click", () => ($("#menu").checked = false)));
}

/* ---------- Carrito (se guarda en localStorage) ---------- */
let carrito = {};
try { carrito = JSON.parse(localStorage.getItem("miguel-carrito")) || {}; } catch (e) { carrito = {}; }
const guardar = () => { try { localStorage.setItem("miguel-carrito", JSON.stringify(carrito)); } catch (e) {} };
function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("on"); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove("on"), 2200); }
function abrirCarrito(v) { $("#drawer").classList.toggle("abierto", v); $("#velo").classList.toggle("on", v); $("#drawer").setAttribute("aria-hidden", !v); if (v) $("#cerrar-carrito").focus(); }
function dialogo(t, p) { $("#dlg-t").textContent = t; $("#dlg-p").textContent = p; $("#dlg").showModal(); }

function pintarCarrito() {
  const ids = Object.keys(carrito).filter(id => PRODUCTOS.some(p => p.id == id));
  let total = 0, cant = 0;
  $("#items").innerHTML = ids.length ? ids.map(id => {
    const p = PRODUCTOS.find(x => x.id == id), q = carrito[id], sub = precioFinal(p) * q;
    total += sub; cant += q;
    return `<div class="item"><img src="${p.imagen}" alt="${p.nombre}">
      <div><h3>${p.nombre}</h3><p>${money(precioFinal(p))} c/u</p>
      <div class="cant"><button data-mas="${id}" data-d="-1" aria-label="Quitar uno">−</button><span>${q}</span><button data-mas="${id}" data-d="1" aria-label="Agregar uno">+</button></div></div>
      <div class="der"><strong>${money(sub)}</strong><button class="borrar" data-del="${id}" aria-label="Eliminar ${p.nombre}">×</button></div></div>`;
  }).join("") : `<p class="vacio">Tu carrito está vacío.<br><a href="productos.html">Ver productos</a></p>`;
  $("#total").textContent = money(total);
  $("#cuenta-carrito").textContent = cant;
  $("#cuenta-carrito").classList.toggle("on", cant > 0);
  guardar();
}
function agregar(id) { carrito[id] = (carrito[id] || 0) + 1; pintarCarrito(); toast("Agregado: " + PRODUCTOS.find(p => p.id == id).nombre); }

function eventosCarrito() {
  $("#abrir-carrito").addEventListener("click", () => abrirCarrito(true));
  $("#cerrar-carrito").addEventListener("click", () => abrirCarrito(false));
  $("#velo").addEventListener("click", () => abrirCarrito(false));
  document.addEventListener("keydown", e => e.key === "Escape" && abrirCarrito(false));
  $("#items").addEventListener("click", e => {
    const m = e.target.closest("[data-mas]"), d = e.target.closest("[data-del]");
    if (m) { const id = m.dataset.mas; carrito[id] += +m.dataset.d; if (carrito[id] < 1) delete carrito[id]; }
    if (d) delete carrito[d.dataset.del];
    pintarCarrito();
  });
  $("#vaciar").addEventListener("click", () => { carrito = {}; pintarCarrito(); });
  $("#finalizar").addEventListener("click", () => {
    if (!Object.keys(carrito).length) return toast("Agrega productos antes de finalizar");
    const t = $("#total").textContent; carrito = {}; pintarCarrito(); abrirCarrito(false);
    dialogo("¡Pedido recibido!", `Total: ${t}. Te contactaremos para coordinar el pago y la entrega.`);
  });
  $("#dlg-ok").addEventListener("click", () => $("#dlg").close());
  document.addEventListener("click", e => { const b = e.target.closest("[data-agregar]"); if (b) agregar(b.dataset.agregar); });
}

/* ---------- Tarjetas de producto ---------- */
function tarjeta(p) {
  const precio = p.descuento
    ? `<s>${money(p.precio)}</s> ${money(precioFinal(p))}` : money(p.precio);
  return `<article class="ofert-1">${p.descuento ? `<span class="etiqueta">-${p.descuento}%</span>` : ""}
    <img src="${p.imagen}" alt="${p.nombre}" loading="lazy">
    <div class="product-txt"><h3>${p.nombre}</h3><p>${p.descripcion}</p>
    <p class="precio">${precio}</p>
    <button class="btn-3" data-agregar="${p.id}">Agregar</button></div></article>`;
}

/* ---------- Páginas ---------- */
function iniciarInicio() {
  $("#destacados").innerHTML = PRODUCTOS.slice(0, 4).map(tarjeta).join("");
  $("#noticias-lista").innerHTML = NOTICIAS.map(n => `<article class="blog-1"><img src="${n.imagen}" alt="" loading="lazy">
    <div class="blog-txt"><h3>${n.titulo}</h3><p>${n.resumen}</p><a href="noticia.html?id=${n.id}" class="btn-4">Leer más</a></div></article>`).join("");
  const f = $("#form-contacto");
  const err = (c, m) => { $(`[name=${c}]`, f).setAttribute("aria-invalid", !!m); $(`#e-${c}`).textContent = m; return !m; };
  f.addEventListener("submit", e => {
    e.preventDefault();
    const nombre = f.nombre.value.trim(), correo = f.correo.value.trim(), msg = f.mensaje.value.trim();
    const ok = [err("nombre", nombre.length < 3 ? "Escribe tu nombre (mínimo 3 letras)." : ""),
      err("correo", /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(correo) ? "" : "Ingresa un correo válido, por ejemplo nombre@correo.com."),
      err("mensaje", msg.length < 10 ? "El mensaje necesita al menos 10 caracteres." : "")].every(Boolean);
    if (!ok) return;
    f.reset(); dialogo("Mensaje enviado", `Gracias, ${nombre}. Te responderemos a ${correo}.`);
  });
}

function iniciarCatalogo() {
  const q = new URLSearchParams(location.search);
  const cat = $("#f-cat"), ord = $("#f-ord"), txt = $("#f-txt"), of = $("#f-of");
  cat.value = q.get("cat") || "todas"; of.checked = q.get("filtro") === "ofertas";
  const pintar = () => {
    let l = PRODUCTOS.filter(p => (cat.value === "todas" || p.categoria === cat.value) && (!of.checked || p.descuento)
      && p.nombre.toLowerCase().includes(txt.value.trim().toLowerCase()));
    if (ord.value === "menor") l.sort((a, b) => precioFinal(a) - precioFinal(b));
    if (ord.value === "mayor") l.sort((a, b) => precioFinal(b) - precioFinal(a));
    $("#resultados").textContent = `${l.length} producto${l.length === 1 ? "" : "s"}`;
    $("#catalogo").innerHTML = l.length ? l.map(tarjeta).join("") : `<p class="vacio">No hay productos con esos filtros. Prueba otra búsqueda.</p>`;
  };
  [cat, ord, of].forEach(c => c.addEventListener("change", pintar));
  txt.addEventListener("input", pintar);
  pintar();
}

function iniciarNoticia() {
  const n = NOTICIAS.find(x => x.id == new URLSearchParams(location.search).get("id")) || NOTICIAS[0];
  document.title = n.titulo + " | Miguel";
  $("#articulo").innerHTML = `<h1>${n.titulo}</h1><img src="${n.imagen}" alt="">${n.texto.map(t => `<p>${t}</p>`).join("")}
    <a href="index.html#noticias" class="btn-4">← Volver a noticias</a>`;
}

document.addEventListener("DOMContentLoaded", () => {
  montarLayout(); eventosCarrito(); pintarCarrito();
  ({ inicio: iniciarInicio, catalogo: iniciarCatalogo, noticia: iniciarNoticia })[document.body.dataset.pagina]?.();
});
